<?php

if( !class_exists( 'litdbscreens' ) ):
class litdbscreens {

	function _mod_enable(){
		return true;
	}
	
	function _ajax_check(){
		if( !isset( $_REQUEST['ajax'] ) ) return;
		$db =& JFactory::getDBO();
		switch( $_REQUEST['ajax'] ){
			default:
				break;
		}
	}

	function _menu(){
		$_items = array(
			'Manage' 				=> '',
			'Contributor' 			=> 'Contributors',
			'Journal' 				=> 'Journals',
			'Literature' 			=> 'Literature',
		#	'LiteratureAudience' 	=> 'Literature Audiences',
		#	'LiteratureContributor' => 'Literature Contributors',
		#	'LiteratureFormat' 		=> 'Literature Formats',
		#	'LiteratureSubject' 	=> 'Literature Subjects',
			'Attributes' 			=> '',
			'ArticleType' 			=> 'Article Types',
			'Audience' 				=> 'Audiences',
			'BookType' 				=> 'Book Types',
			'ContributorType' 		=> 'Contributor Types',
			'Format' 				=> 'Formats',
			'ReportType' 			=> 'Report Types',
			'Subject' 				=> 'Subjects',
		);
		?>
		<ul style="float:right; margin:10px; padding:10px; list-style-type:none; background:#ccc; border:#999; border-radius:5px;">
			<?php foreach( $_items as $task => $label ): ?>
				<?php if( '' == $label ): ?>
					<li><strong><?php echo strtoupper( $task ); ?>:</strong></li>
				<?php continue; endif; ?>
				<li<?php if( $_GET['task'] == $task ): ?> class="current" style="font-weight:700;"<?php endif; ?>><a href="?option=com_literaturedatabase&amp;task=<?php echo $task; ?>"><?php echo $label; ?></a></li>
			<?php endforeach; ?>
		</ul>
		<?php
	}
	
	function _css(){
		$folder = JURI::base().'components/com_literaturedatabase/';
		?>
		<style>
			div#toolbar-box {display:none;}
			
			table.list-table {border:1px solid #999; background:#ddd;}
			table.list-table thead {background:#999; color:#fff;}
			table.list-table thead tr {}
			table.list-table thead tr th {margin:0; padding:5px 10px; font-size:17px; text-shadow:1px 1px 0 rgba(0,0,0,.3);}
			table.list-table tfoot {background:#999; color:#fff;}
			table.list-table tfoot tr {}
			table.list-table tfoot tr th {margin:0; padding:5px 10px; font-size:17px; text-shadow:1px 1px 0 rgba(0,0,0,.3);}
			table.list-table tbody {vertical-align:top;}
			table.list-table tbody tr {}
			table.list-table tbody tr:hover {background:#dfd;}
			table.list-table tbody tr th {border-bottom:1px dashed #999;}
			table.list-table tbody tr td {border-left:1px solid #999; border-bottom:1px dashed #999;}
			table.list-table tbody tr td input[type=text] {width:95%; display:block; margin:0 2px;}
			
			table.form-table {}
			table.form-table tr {}
			table.form-table tr th {text-align:right; padding:10px 5px; vertical-align:top; white-space:nowrap;}
			table.form-table tr td {}
			table.form-table tr td .widefat {width:400px; padding:5px; font-size:12px;}
			table.form-table tr td textarea.widefat {height:75px;}
			
			.link-edit {display:inline-block; height:16px; width:16px; margin:0 5px; padding:0; text-indent:-5000px; overflow:hidden; background:url('<?php echo $folder; ?>images/pencil.png') 50% 50% no-repeat;}
			.link-delete {display:inline-block; height:16px; width:16px; margin:0 5px; padding:0; text-indent:-5000px; overflow:hidden; background:url('<?php echo $folder; ?>images/delete.png') 50% 50% no-repeat;}
			
			ul.lit_attrib_list {margin:0; padding:5px 5px 0; list-style-position:inside;}
			ul.lit_attrib_list li {margin-bottom:5px; white-space:nowrap;}
			
			span.lit-yes {color:#800; font-weight:700; font-size:1.5em;}
			span.lit-no {color:#080; font-weight:700; font-size:1.5em;}
			span.lit-none {color:#888; font-size:.8em;}
			
			span.more {display:block; min-width:270px;}
			span.more span.ellipses {display:inline;}
			span.more span.more-text {display:none;}
			span.more:hover span.ellipses {display:none;}
			span.more:hover span.more-text {display:inline;}
		</style>
		<link rel="stylesheet" href="<?php echo $folder; ?>chosen/chosen.css" />
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
		<script src="/~george/wp/wp-includes/js/jquery/jquery.js"></script>
		<script>jQuery.noConflict();</script>
		<script src="<?php echo $folder; ?>chosen/chosen.jquery.min.js"></script>
		<script>
		jQuery(document).ready(function($){
			$('.chosen-ui').chosen();
		})
		</script>
		<?php
	}

	function _default(){
		?>
		<h1>Default Screen</h1>
		<p>You have reached this screen in error.  Please select from one of the options available to the right.</p>
		<?php
	}
	
	// Abstracted out here to enable future inclusion of url-query specification of ordering
	function _order_by( $o = 'ID' ){
		return " ORDER BY `$o` ASC ";
	}
	
// ================================================
// === Detailed Pages =============================
// ================================================
	
	function Contributor(){
		$table = __FUNCTION__;
		self::_contributor_catch( $table );
		$db =& JFactory::getDBO();
		$db->setQuery( "SELECT * FROM `jos_litdb_$table` ".self::_order_by() );
		$items = $db->loadAssocList(); // items to show in the table
		?>
		<h1><?php echo $table; ?></h1>
		<form method="post" action="?option=com_literaturedatabase&amp;task=<?php echo $table; ?>">
		<table class="list-table">
			<thead>
				<tr>
					<th scope="col"></th>
					<th scope="col">ID</th>
					<th scope="col">Prefix</th>
					<th scope="col">First Name</th>
					<th scope="col">Middle</th>
					<th scope="col">Last Name / Corp</th>
					<th scope="col">Suffix</th>
					<?php if( self::_mod_enable() ): ?><th scope="col">Actions</th><?php endif; ?>
				</tr>
			</thead>
			<tfoot>
				<tr>
					<th scope="col"></th>
					<th scope="col">ID</th>
					<th scope="col">Prefix</th>
					<th scope="col">First Name</th>
					<th scope="col">Middle</th>
					<th scope="col">Last Name / Corp</th>
					<th scope="col">Suffix</th>
					<?php if( self::_mod_enable() ): ?><th scope="col">Actions</th><?php endif; ?>
				</tr>
			</tfoot>
			<tbody>
				<?php if( $items ): foreach( $items as $k => $v ): ?>
				<tr id="row-item-<?php echo $v['ID']; ?>">
					<th scope="row"><input type="checkbox" name="ids[]" value="<?php echo $v['ID']; ?>" /></th>
					<td><?php echo $v['ID']; ?></td>
					<?php if( self::_mod_enable() && isset( $_GET['edit'] ) && ( $v['ID'] == $_GET['edit'] ) ): ?>
						<input type="hidden" name="edit-ID" value="<?php echo $v['ID']; ?>" />
						<td><input type="text" name="edit-Prefix" value="<?php echo $v['Prefix']; ?>" /></td>
						<td><input type="text" name="edit-FirstName" value="<?php echo $v['FirstName']; ?>" /></td>
						<td><input type="text" name="edit-Middle" value="<?php echo $v['Middle']; ?>" /></td>
						<td><input type="text" name="edit-LastNameCorp" value="<?php echo $v['LastNameCorp']; ?>" /></td>
						<td><input type="text" name="edit-Suffix" value="<?php echo $v['Suffix']; ?>" /></td>
						<td><input type="submit" name="edit-action" value="Edit &rarr;" /></td>
					<?php else: ?>
						<td><?php echo $v['Prefix']; ?></td>
						<td><?php echo $v['FirstName']; ?></td>
						<td><?php echo $v['Middle']; ?></td>
						<td><?php echo $v['LastNameCorp']; ?></td>
						<td><?php echo $v['Suffix']; ?></td>
						<?php if( self::_mod_enable() ): ?>
							<td>
								<a class="link-edit" href="?option=<?php echo $_GET['option']; ?>&amp;task=<?php echo $_GET['task']; ?>&amp;edit=<?php echo $v['ID']; ?>#row-item-<?php echo $v['ID']; ?>">Edit</a>
								<a class="link-delete" href="?option=<?php echo $_GET['option']; ?>&amp;task=<?php echo $_GET['task']; ?>&amp;delete=<?php echo $v['ID']; ?>">Delete</a>
							</td>
						<?php endif; ?>
					<?php endif; ?>
				</tr>
				<?php endforeach; endif; ?>
				<?php if( self::_mod_enable() && !isset( $_GET['edit'] ) ): ?>
				<tr>
					<th style="border-bottom:0;"></th>
					<td style="border-bottom:0;">NEW</td>
					<td style="border-bottom:0;"><input type="text" name="add-Prefix" /></td>
					<td style="border-bottom:0;"><input type="text" name="add-FirstName" /></td>
					<td style="border-bottom:0;"><input type="text" name="add-Middle" /></td>
					<td style="border-bottom:0;"><input type="text" name="add-LastNameCorp" /></td>
					<td style="border-bottom:0;"><input type="text" name="add-Suffix" /></td>
					<td style="border-bottom:0;"><input type="submit" name="add-action" value="Add &rarr;" /></td>
				</tr>
				<?php endif; ?>
			</tbody>
		</table>
		</form>
		<?php
	}
	function _contributor_catch( $table ){
		$did = false;
		
		if( isset( $_REQUEST['add-action'] ) ){
			if( $id = self::_add( $table, array( 
						'Prefix' 		=> $_REQUEST['add-Prefix'], 
						'FirstName' 	=> $_REQUEST['add-FirstName'], 
						'Middle' 		=> $_REQUEST['add-Middle'], 
						'LastNameCorp' 	=> $_REQUEST['add-LastNameCorp'], 
						'Suffix' 		=> $_REQUEST['add-Suffix'], 
					) ) ){
				$did = true;
			}
		}
		
		if( isset( $_REQUEST['edit-action'] ) ){
			if( $id = (int) $_REQUEST['edit-ID'] ){
				if( self::_edit( $table, $id, array( 
							'Prefix' 		=> $_REQUEST['edit-Prefix'], 
							'FirstName' 	=> $_REQUEST['edit-FirstName'], 
							'Middle' 		=> $_REQUEST['edit-Middle'], 
							'LastNameCorp' 	=> $_REQUEST['edit-LastNameCorp'], 
							'Suffix' 		=> $_REQUEST['edit-Suffix'], 
						) ) ){
					$did = true;
				}
			}
		}
		
		if( isset( $_REQUEST['delete'] ) ){
			if( $id = (int) $_REQUEST['delete'] ){
				if( self::_delete( $table, $id ) ){
					$did = true;
				}
			}
		}
		
		if( $did ){
			header( "Location: ?option=com_literaturedatabase&task=$table#row-item-$id" );
			exit;
		}
	}
	function Journal(){
		$table = __FUNCTION__;
		self::_journal_catch( $table );
		$db =& JFactory::getDBO();
		$db->setQuery( "SELECT * FROM `jos_litdb_$table` ".self::_order_by('JID') );
		$items = $db->loadAssocList(); // items to show in the table
		?>
		<h1><?php echo $table; ?></h1>
		<form method="post" action="?option=com_literaturedatabase&amp;task=<?php echo $table; ?>">
		<table class="list-table">
			<thead>
				<tr>
					<th scope="col"></th>
					<th scope="col">JID</th>
					<th scope="col">Name</th>
					<th scope="col">Publisher</th>
					<th scope="col">City</th>
					<th scope="col">State</th>
					<th scope="col">Country</th>
					<th scope="col">ISSN</th>
					<?php if( self::_mod_enable() ): ?><th scope="col">Actions</th><?php endif; ?>
				</tr>
			</thead>
			<tfoot>
				<tr>
					<th scope="col"></th>
					<th scope="col">JID</th>
					<th scope="col">Name</th>
					<th scope="col">Publisher</th>
					<th scope="col">City</th>
					<th scope="col">State</th>
					<th scope="col">Country</th>
					<th scope="col">ISSN</th>
					<?php if( self::_mod_enable() ): ?><th scope="col">Actions</th><?php endif; ?>
				</tr>
			</tfoot>
			<tbody>
				<?php if( $items ): foreach( $items as $k => $v ): ?>
				<tr id="row-item-<?php echo $v['JID']; ?>">
					<th scope="row"><input type="checkbox" name="ids[]" value="<?php echo $v['JID']; ?>" /></th>
					<td><?php echo $v['JID']; ?></td>
					<?php if( self::_mod_enable() && isset( $_GET['edit'] ) && ( $v['JID'] == $_GET['edit'] ) ): ?>
						<input type="hidden" name="edit-JID" value="<?php echo $v['JID']; ?>" />
						<td><input type="text" name="edit-Name" value="<?php echo $v['Name']; ?>" /></td>
						<td><input type="text" name="edit-Publisher" value="<?php echo $v['Publisher']; ?>" /></td>
						<td><input type="text" name="edit-City" value="<?php echo $v['City']; ?>" /></td>
						<td><input type="text" name="edit-State" value="<?php echo $v['State']; ?>" /></td>
						<td><input type="text" name="edit-Country" value="<?php echo $v['Country']; ?>" /></td>
						<td><input type="text" name="edit-ISSN" value="<?php echo $v['ISSN']; ?>" /></td>
						<td><input type="submit" name="edit-action" value="Edit &rarr;" /></td>
					<?php else: ?>
						<td><?php echo $v['Name']; ?></td>
						<td><?php echo $v['Publisher']; ?></td>
						<td><?php echo $v['City']; ?></td>
						<td><?php echo $v['State']; ?></td>
						<td><?php echo $v['Country']; ?></td>
						<td><?php echo $v['ISSN']; ?></td>
						<?php if( self::_mod_enable() ): ?>
							<td>
								<a class="link-edit" href="?option=<?php echo $_GET['option']; ?>&amp;task=<?php echo $_GET['task']; ?>&amp;edit=<?php echo $v['JID']; ?>#row-item-<?php echo $v['JID']; ?>">Edit</a>
								<a class="link-delete" href="?option=<?php echo $_GET['option']; ?>&amp;task=<?php echo $_GET['task']; ?>&amp;delete=<?php echo $v['JID']; ?>">Delete</a>
							</td>
						<?php endif; ?>
					<?php endif; ?>
				</tr>
				<?php endforeach; endif; ?>
				<?php if( self::_mod_enable() && !isset( $_GET['edit'] ) ): ?>
				<tr>
					<th style="border-bottom:0;"></th>
					<td style="border-bottom:0;">NEW</td>
					<td style="border-bottom:0;"><input type="text" name="add-Name" /></td>
					<td style="border-bottom:0;"><input type="text" name="add-Publisher" /></td>
					<td style="border-bottom:0;"><input type="text" name="add-City" /></td>
					<td style="border-bottom:0;"><input type="text" name="add-State" /></td>
					<td style="border-bottom:0;"><input type="text" name="add-Country" /></td>
					<td style="border-bottom:0;"><input type="text" name="add-ISSN" /></td>
					<td style="border-bottom:0;"><input type="submit" name="add-action" value="Add &rarr;" /></td>
				</tr>
				<?php endif; ?>
			</tbody>
		</table>
		</form>
		<?php
	}
	function _journal_catch( $table ){
		$did = false;
		
		if( isset( $_REQUEST['add-action'] ) ){
			if( $id = self::_add( $table, array( 
						'Name' 		=> $_REQUEST['add-Name'], 
						'Publisher' => $_REQUEST['add-Publisher'], 
						'City' 		=> $_REQUEST['add-City'], 
						'State' 	=> $_REQUEST['add-State'], 
						'Country' 	=> $_REQUEST['add-Country'],  
						'ISSN' 		=> $_REQUEST['add-ISSN'], 
					) ) ){
				$did = true;
			}
		}
		
		if( isset( $_REQUEST['edit-action'] ) ){
			if( $id = (int) $_REQUEST['edit-JID'] ){
				if( self::_edit( $table, $id, array( 
							'Name' 		=> $_REQUEST['edit-Name'], 
							'Publisher' => $_REQUEST['edit-Publisher'], 
							'City' 		=> $_REQUEST['edit-City'], 
							'State' 	=> $_REQUEST['edit-State'], 
							'Country' 	=> $_REQUEST['edit-Country'],  
							'ISSN' 		=> $_REQUEST['edit-ISSN'], 
						), 'JID' ) ){
					$did = true;
				}
			}
		}
		
		if( isset( $_REQUEST['delete'] ) ){
			if( $id = (int) $_REQUEST['delete'] ){
				if( self::_delete( $table, $id, 'JID' ) ){
					$did = true;
				}
			}
		}
		
		if( $did ){
			header( "Location: ?option=com_literaturedatabase&task=$table#row-item-$id" );
			exit;
		}
	}
	function Literature(){
		$table = __FUNCTION__;
		self::_literature_catch( $table );
		$db =& JFactory::getDBO();
		$db->setQuery( "SELECT * FROM `jos_litdb_$table` ".self::_order_by('LitID') );
		$items = $db->loadAssocList(); // items to show in the table
		?>
		<h1><?php echo $table; ?></h1>
		<form method="post" action="?option=com_literaturedatabase&amp;task=<?php echo $table; ?>">
<?php if( isset( $_GET['new'] ) || isset( $_GET['edit'] ) ): ?>
		
		<p><a href="?option=com_literaturedatabase&amp;task=<?php echo $table; ?>">&laquo; Back</a></p>
		
		<?php
			$x = array(); // blank entry
			if( ! empty( $_GET['edit'] ) ){
				$id = (int) $_GET['edit'];
				$db->setQuery( "SELECT * FROM `jos_litdb_$table` WHERE `LitID` = '$id' LIMIT 1" );
				$x = $db->loadAssoc(); // single item we're editing
			}
			
		?>
		
		<table class="form-table">
			<?php
				self::_form_row( 'LitID', 				  'LitID', 					self::_val( $x, 'LitID', 'NEW' ), 			'display' );
				self::_form_row( 'Contributors', 		  'Contributors', 			array_keys( self::_lit_contributors( self::_val( $x, 'LitID', 'abc123' ) ) ),
																																'multi_assoc', self::_lit_contributors() );
				self::_form_row( 'Format', 		  		  'Format', 				array_keys( self::_lit_formats( self::_val( $x, 'LitID', 'abc123' ) ) ),
																																'multi_assoc', self::_lit_subtable_opts( 'Format', array() ) );
				self::_form_row( 'TypeID', 				  'TypeID', 				self::_val( $x, 'TypeID' ), 				'dropdown_assoc', self::_lit_subtable_opts( 'ArticleType', array( '' => '' ) ) );
				self::_form_row( 'ReportType', 			  'ReportType', 			self::_val( $x, 'ReportType' ), 			'dropdown_assoc', self::_lit_subtable_opts( 'ReportType', array( '' => '' ) ) );
				self::_form_row( 'BookType', 			  'BookType', 				self::_val( $x, 'BookType' ), 				'dropdown_assoc', self::_lit_subtable_opts( 'BookType', array( '' => '' ) ) );
				self::_form_row( 'AdditionalPubInfo',	  'AdditionalPubInfo', 		self::_val( $x, 'AdditionalPubInfo' ), 		'textarea' );
				self::_form_row( 'TTA', 				  'TTA', 					self::_val( $x, 'TTA' ), 					'yn' );
				self::_form_row( 'CopyrightCheck', 		  'CopyrightCheck', 		self::_val( $x, 'CopyrightCheck' ), 		'yn' );
				self::_form_row( 'FullTextAvailable',	  'FullTextAvailable', 		self::_val( $x, 'FullTextAvailable' ), 		'yn' );
				self::_form_row( 'Annotations', 		  'Annotations', 			self::_val( $x, 'Annotations' ), 			'textarea' );
				self::_form_row( 'DateEntered', 		  'DateEntered', 			self::_val( $x, 'DateEntered' ), 			'text' );
				self::_form_row( 'IPSourceTitle', 		  'IPSourceTitle', 			self::_val( $x, 'IPSourceTitle' ), 			'text' );
				self::_form_row( 'ChapterSecArticleTitle','ChapterSecArticleTitle', self::_val( $x, 'ChapterSecArticleTitle' ), 'text' );
				self::_form_row( 'JournalID', 			  'JournalID', 				self::_val( $x, 'JournalID' ), 				'text' );
				self::_form_row( 'JournalName', 		  'JournalName', 			self::_val( $x, 'JournalName' ), 			'text' );
				self::_form_row( 'ISBNISSN', 			  'ISBNISSN', 				self::_val( $x, 'ISBNISSN' ), 				'text' );
				self::_form_row( 'IPVolume', 			  'IPVolume', 				self::_val( $x, 'IPVolume' ), 				'text' );
				self::_form_row( 'IPIssue', 			  'IPIssue', 				self::_val( $x, 'IPIssue' ), 				'text' );
				self::_form_row( 'IPEdition', 			  'IPEdition', 				self::_val( $x, 'IPEdition' ), 				'text' );
				self::_form_row( 'NewsSection', 		  'NewsSection', 			self::_val( $x, 'NewsSection' ), 			'text' );
				self::_form_row( 'IPSeries', 			  'IPSeries', 				self::_val( $x, 'IPSeries' ), 				'text' );
				self::_form_row( 'IPYear', 				  'IPYear', 				self::_val( $x, 'IPYear' ), 				'text' );
				self::_form_row( 'IPMonth', 			  'IPMonth', 				self::_val( $x, 'IPMonth' ), 				'text' );
				self::_form_row( 'IPDay', 				  'IPDay', 					self::_val( $x, 'IPDay' ), 					'text' );
				self::_form_row( 'IPReprint', 			  'IPReprint', 				self::_val( $x, 'IPReprint' ), 				'yn' );
				self::_form_row( 'IPUnpublished', 		  'IPUnpublished', 			self::_val( $x, 'IPUnpublished' ), 			'yn' );
				self::_form_row( 'IPStartPage', 		  'IPStartPage', 			self::_val( $x, 'IPStartPage' ), 			'text' );
				self::_form_row( 'IPEndPage', 			  'IPEndPage', 				self::_val( $x, 'IPEndPage' ), 				'text' );
				self::_form_row( 'IPNonConsecutive', 	  'IPNonConsecutive', 		self::_val( $x, 'IPNonConsecutive' ), 		'yn' );
				self::_form_row( 'PDFfile', 			  'PDFfile', 				self::_val( $x, 'PDFfile' ), 				'text' );
				self::_form_row( 'WebsiteTitle', 		  'WebsiteTitle', 			self::_val( $x, 'WebsiteTitle' ), 			'text' );
				self::_form_row( 'URL', 				  'URL', 					self::_val( $x, 'URL' ), 					'text' );
				self::_form_row( 'DOI', 				  'DOI', 					self::_val( $x, 'DOI' ), 					'text' );
				self::_form_row( 'ElecPubYear', 		  'ElecPubYear', 			self::_val( $x, 'ElecPubYear' ), 			'text' );
				self::_form_row( 'ElecPubMonth', 		  'ElecPubMonth', 			self::_val( $x, 'ElecPubMonth' ), 			'text' );
				self::_form_row( 'ElectPubDay', 		  'ElectPubDay', 			self::_val( $x, 'ElectPubDay' ), 			'text' );
				self::_form_row( 'AccessedYear', 		  'AccessedYear', 			self::_val( $x, 'AccessedYear' ), 			'text' );
				self::_form_row( 'AccessedMonth', 		  'AccessedMonth', 			self::_val( $x, 'AccessedMonth' ), 			'text' );
				self::_form_row( 'AccessedDay', 		  'AccessedDay', 			self::_val( $x, 'AccessedDay' ), 			'text' );
				self::_form_row( 'OriginallyPrint', 	  'OriginallyPrint', 		self::_val( $x, 'OriginallyPrint' ), 		'yn' );
				self::_form_row( 'OnlineJournal', 		  'OnlineJournal', 			self::_val( $x, 'OnlineJournal' ), 			'yn' );
				self::_form_row( 'APA1', 				  'APA1', 					self::_val( $x, 'APA1' ), 					'textarea' );
				self::_form_row( 'APA2', 				  'APA2', 					self::_val( $x, 'APA2' ), 					'textarea' );
				self::_form_row( 'APA3', 				  'APA3', 					self::_val( $x, 'APA3' ), 					'textarea' );
				self::_form_row( 'Publisher', 			  'Publisher', 				self::_val( $x, 'Publisher' ), 				'text' );
				self::_form_row( 'City', 				  'City', 					self::_val( $x, 'City' ), 					'text' );
				self::_form_row( 'State', 				  'State', 					self::_val( $x, 'State' ), 					'text' );
				self::_form_row( 'Audience', 			  'Audience', 				explode( ';', self::_val($x,'Audience') ), 	'multi_assoc', self::_lit_subtable_opts( 'Audience', array() ) );
				self::_form_row( 'Subject', 			  'Subject', 				explode( ';', self::_val($x,'Subject') ), 	'multi_assoc', self::_lit_subtable_opts( 'Subject', array() ) );
				self::_form_row( 'Submit',                'Submit',                 'Submit',                                   'submit' );
			?>
		</table>

<?php else: ?>
		<h3><a href="?option=com_literaturedatabase&amp;task=<?php echo $table; ?>&amp;new">Add New &raquo;</a></h3>
		<table class="list-table">
			<thead>
				<tr>
					<th scope="col"></th>
					<?php if( self::_mod_enable() ): ?><th scope="col">Actions</th><?php endif; ?>
					<th scope="col">LitID</th>
					<th scope="col">Contributors</th>
					<th scope="col">Formats</th>
					<th scope="col">TypeID</th>
					<th scope="col">ReportType</th>
					<th scope="col">BookType</th>
					<th scope="col">AdditionalPubInfo</th>
					<th scope="col">TTA</th>
					<th scope="col">CopyrightCheck</th>
					<th scope="col">FullTextAvailable</th>
					<th scope="col">Annotations</th>
					<th scope="col">DateEntered</th>
					<th scope="col">IPSourceTitle</th>
					<th scope="col">ChapterSecArticleTitle</th>
					<th scope="col">JournalID</th>
					<th scope="col">JournalName</th>
					<th scope="col">ISBNISSN</th>
					<th scope="col">IPVolume</th>
					<th scope="col">IPIssue</th>
					<th scope="col">IPEdition</th>
					<th scope="col">NewsSection</th>
					<th scope="col">IPSeries</th>
					<th scope="col">IPYear</th>
					<th scope="col">IPMonth</th>
					<th scope="col">IPDay</th>
					<th scope="col">IPReprint</th>
					<th scope="col">IPUnpublished</th>
					<th scope="col">IPStartPage</th>
					<th scope="col">IPEndPage</th>
					<th scope="col">IPNonConsecutive</th>
					<th scope="col">PDFfile</th>
					<th scope="col">WebsiteTitle</th>
					<th scope="col">URL</th>
					<th scope="col">DOI</th>
					<th scope="col">ElecPubYear</th>
					<th scope="col">ElecPubMonth</th>
					<th scope="col">ElectPubDay</th>
					<th scope="col">AccessedYear</th>
					<th scope="col">AccessedMonth</th>
					<th scope="col">AccessedDay</th>
					<th scope="col">OriginallyPrint</th>
					<th scope="col">OnlineJournal</th>
					<th scope="col">APA1</th>
					<th scope="col">APA2</th>
					<th scope="col">APA3</th>
					<th scope="col">Publisher</th>
					<th scope="col">City</th>
					<th scope="col">State</th>
					<th scope="col">Audience</th>
					<th scope="col">Subject</th>
					<?php if( self::_mod_enable() ): ?><th scope="col">Actions</th><?php endif; ?>
				</tr>
			</thead>
			<tfoot>
				<tr>
					<th scope="col"></th>
					<?php if( self::_mod_enable() ): ?><th scope="col">Actions</th><?php endif; ?>
					<th scope="col">LitID</th>
					<th scope="col">Contributors</th>
					<th scope="col">Formats</th>
					<th scope="col">TypeID</th>
					<th scope="col">ReportType</th>
					<th scope="col">BookType</th>
					<th scope="col">AdditionalPubInfo</th>
					<th scope="col">TTA</th>
					<th scope="col">CopyrightCheck</th>
					<th scope="col">FullTextAvailable</th>
					<th scope="col">Annotations</th>
					<th scope="col">DateEntered</th>
					<th scope="col">IPSourceTitle</th>
					<th scope="col">ChapterSecArticleTitle</th>
					<th scope="col">JournalID</th>
					<th scope="col">JournalName</th>
					<th scope="col">ISBNISSN</th>
					<th scope="col">IPVolume</th>
					<th scope="col">IPIssue</th>
					<th scope="col">IPEdition</th>
					<th scope="col">NewsSection</th>
					<th scope="col">IPSeries</th>
					<th scope="col">IPYear</th>
					<th scope="col">IPMonth</th>
					<th scope="col">IPDay</th>
					<th scope="col">IPReprint</th>
					<th scope="col">IPUnpublished</th>
					<th scope="col">IPStartPage</th>
					<th scope="col">IPEndPage</th>
					<th scope="col">IPNonConsecutive</th>
					<th scope="col">PDFfile</th>
					<th scope="col">WebsiteTitle</th>
					<th scope="col">URL</th>
					<th scope="col">DOI</th>
					<th scope="col">ElecPubYear</th>
					<th scope="col">ElecPubMonth</th>
					<th scope="col">ElectPubDay</th>
					<th scope="col">AccessedYear</th>
					<th scope="col">AccessedMonth</th>
					<th scope="col">AccessedDay</th>
					<th scope="col">OriginallyPrint</th>
					<th scope="col">OnlineJournal</th>
					<th scope="col">APA1</th>
					<th scope="col">APA2</th>
					<th scope="col">APA3</th>
					<th scope="col">Publisher</th>
					<th scope="col">City</th>
					<th scope="col">State</th>
					<th scope="col">Audience</th>
					<th scope="col">Subject</th>
					<?php if( self::_mod_enable() ): ?><th scope="col">Actions</th><?php endif; ?>
				</tr>
			</tfoot>
			<tbody>
				<?php if( $items ): foreach( $items as $k => $v ): ?>
				<tr id="row-item-<?php echo $v['LitID']; ?>">
					<th scope="row"><input type="checkbox" name="ids[]" value="<?php echo $v['LitID']; ?>" /></th>
					<?php if( self::_mod_enable() ): ?><td><a class="link-edit" href="?option=<?php echo $_GET['option']; ?>&amp;task=<?php echo $_GET['task']; ?>&amp;edit=<?php echo $v['LitID']; ?>">Edit</a>
						<a class="link-delete" href="?option=<?php echo $_GET['option']; ?>&amp;task=<?php echo $_GET['task']; ?>&amp;delete=<?php echo $v['LitID']; ?>">Delete</a></td><?php endif; ?>
					<td><?php echo $v['LitID']; ?></td>
					<td><?php echo self::_array_to_list( self::_lit_contributors( $v['LitID'] ) ); ?></td>
					<td><?php echo self::_array_to_list( self::_lit_formats( $v['LitID'] ) ); ?></td>
					<td><?php echo self::_lit_single_attrib('ArticleType',$v['TypeID']); ?></td>
					<td><?php echo self::_lit_single_attrib('ReportType',$v['ReportType']); ?></td>
					<td><?php echo self::_lit_single_attrib('BookType',$v['BookType']); ?></td>
					<td><?php echo self::_substr($v['AdditionalPubInfo']); ?></td>
					<td><?php echo self::_y_n($v['TTA']); ?></td>
					<td><?php echo self::_y_n($v['CopyrightCheck']); ?></td>
					<td><?php echo self::_y_n($v['FullTextAvailable']); ?></td>
					<td><?php echo self::_substr($v['Annotations']); ?></td>
					<td><?php echo $v['DateEntered']; ?></td>
					<td><?php echo $v['IPSourceTitle']; ?></td>
					<td><?php echo $v['ChapterSecArticleTitle']; ?></td>
					<td><?php echo $v['JournalID']; ?></td>
					<td><?php echo $v['JournalName']; ?></td>
					<td><?php echo $v['ISBNISSN']; ?></td>
					<td><?php echo $v['IPVolume']; ?></td>
					<td><?php echo $v['IPIssue']; ?></td>
					<td><?php echo $v['IPEdition']; ?></td>
					<td><?php echo $v['NewsSection']; ?></td>
					<td><?php echo $v['IPSeries']; ?></td>
					<td><?php echo $v['IPYear']; ?></td>
					<td><?php echo $v['IPMonth']; ?></td>
					<td><?php echo $v['IPDay']; ?></td>
					<td><?php echo self::_y_n($v['IPReprint']); ?></td>
					<td><?php echo self::_y_n($v['IPUnpublished']); ?></td>
					<td><?php echo $v['IPStartPage']; ?></td>
					<td><?php echo $v['IPEndPage']; ?></td>
					<td><?php echo self::_y_n($v['IPNonConsecutive']); ?></td>
					<td><?php echo $v['PDFfile']; ?></td>
					<td><?php echo $v['WebsiteTitle']; ?></td>
					<td><?php echo self::_link($v['URL']); ?></td>
					<td><?php echo $v['DOI']; ?></td>
					<td><?php echo $v['ElecPubYear']; ?></td>
					<td><?php echo $v['ElecPubMonth']; ?></td>
					<td><?php echo $v['ElectPubDay']; ?></td>
					<td><?php echo $v['AccessedYear']; ?></td>
					<td><?php echo $v['AccessedMonth']; ?></td>
					<td><?php echo $v['AccessedDay']; ?></td>
					<td><?php echo self::_y_n($v['OriginallyPrint']); ?></td>
					<td><?php echo self::_y_n($v['OnlineJournal']); ?></td>
					<td><?php echo self::_substr($v['APA1']); ?></td>
					<td><?php echo self::_substr($v['APA2']); ?></td>
					<td><?php echo self::_substr($v['APA3']); ?></td>
					<td><?php echo $v['Publisher']; ?></td>
					<td><?php echo $v['City']; ?></td>
					<td><?php echo $v['State']; ?></td>
					<td><?php echo self::_lit_attrib_list('Audience',$v['Audience']); ?></td>
					<td><?php echo self::_lit_attrib_list('Subject',$v['Subject']); ?></td>
					<?php if( self::_mod_enable() ): ?><td><a class="link-edit" href="?option=<?php echo $_GET['option']; ?>&amp;task=<?php echo $_GET['task']; ?>&amp;edit=<?php echo $v['LitID']; ?>">Edit</a>
						<a class="link-delete" href="?option=<?php echo $_GET['option']; ?>&amp;task=<?php echo $_GET['task']; ?>&amp;delete=<?php echo $v['LitID']; ?>">Delete</a></td><?php endif; ?>
				</tr>
				<?php endforeach; endif; ?>
			</tbody>
		</table>
<?php endif; ?>
		</form>
		<?php
	}
	function _literature_catch( $table ){
		$did = false;
		
		$LitID = self::_val( $_POST, 'LitID' );
		
		if( empty( $LitID ) ) return;
		
		$lit = array(
		#	"LitID" 					=> self::_val( $_POST, 'LitID' ),
			"TypeID" 					=> self::_val( $_POST, 'TypeID' ),
			"ReportType" 				=> self::_val( $_POST, 'ReportType' ),
			"BookType" 					=> self::_val( $_POST, 'BookType' ),
			"AdditionalPubInfo" 		=> self::_val( $_POST, 'AdditionalPubInfo' ),
			"TTA" 						=> self::_val( $_POST, 'TTA' ),
			"CopyrightCheck" 			=> self::_val( $_POST, 'CopyrightCheck' ),
			"FullTextAvailable" 		=> self::_val( $_POST, 'FullTextAvailable' ),
			"Annotations" 				=> self::_val( $_POST, 'Annotations' ),
			"DateEntered" 				=> self::_val( $_POST, 'DateEntered' ),
			"IPSourceTitle" 			=> self::_val( $_POST, 'IPSourceTitle' ),
			"ChapterSecArticleTitle" 	=> self::_val( $_POST, 'ChapterSecArticleTitle' ),
			"JournalID" 				=> self::_val( $_POST, 'JournalID' ),
			"JournalName" 				=> self::_val( $_POST, 'JournalName' ),
			"ISBNISSN" 					=> self::_val( $_POST, 'ISBNISSN' ),
			"IPVolume" 					=> self::_val( $_POST, 'IPVolume' ),
			"IPIssue" 					=> self::_val( $_POST, 'IPIssue' ),
			"IPEdition" 				=> self::_val( $_POST, 'IPEdition' ),
			"NewsSection" 				=> self::_val( $_POST, 'NewsSection' ),
			"IPSeries" 					=> self::_val( $_POST, 'IPSeries' ),
			"IPYear" 					=> self::_val( $_POST, 'IPYear' ),
			"IPMonth" 					=> self::_val( $_POST, 'IPMonth' ),
			"IPDay" 					=> self::_val( $_POST, 'IPDay' ),
			"IPReprint" 				=> self::_val( $_POST, 'IPReprint' ),
			"IPUnpublished" 			=> self::_val( $_POST, 'IPUnpublished' ),
			"IPStartPage" 				=> self::_val( $_POST, 'IPStartPage' ),
			"IPEndPage" 				=> self::_val( $_POST, 'IPEndPage' ),
			"IPNonConsecutive" 			=> self::_val( $_POST, 'IPNonConsecutive' ),
			"PDFfile" 					=> self::_val( $_POST, 'PDFfile' ),
			"WebsiteTitle" 				=> self::_val( $_POST, 'WebsiteTitle' ),
			"URL" 						=> self::_val( $_POST, 'URL' ),
			"DOI" 						=> self::_val( $_POST, 'DOI' ),
			"ElecPubYear" 				=> self::_val( $_POST, 'ElecPubYear' ),
			"ElecPubMonth" 				=> self::_val( $_POST, 'ElecPubMonth' ),
			"ElectPubDay" 				=> self::_val( $_POST, 'ElectPubDay' ),
			"AccessedYear" 				=> self::_val( $_POST, 'AccessedYear' ),
			"AccessedMonth" 			=> self::_val( $_POST, 'AccessedMonth' ),
			"AccessedDay" 				=> self::_val( $_POST, 'AccessedDay' ),
			"OriginallyPrint" 			=> self::_val( $_POST, 'OriginallyPrint' ),
			"OnlineJournal" 			=> self::_val( $_POST, 'OnlineJournal' ),
			"APA1" 						=> self::_val( $_POST, 'APA1' ),
			"APA2" 						=> self::_val( $_POST, 'APA2' ),
			"APA3" 						=> self::_val( $_POST, 'APA3' ),
			"Publisher" 				=> self::_val( $_POST, 'Publisher' ),
			"City" 						=> self::_val( $_POST, 'City' ),
			"State" 					=> self::_val( $_POST, 'State' ),
			"Audience" 					=> implode( ';', self::_val( $_POST, 'Audience' ) ),
			"Subject" 					=> implode( ';', self::_val( $_POST, 'Subject' ) ),
		);
		
	#	echo "<pre>".print_r( $_POST, true )."</pre>";
	#	echo "<pre>".print_r( $lit, true )."</pre>";
		
		if( 'NEW' == $LitID ){
			if( $LitID = self::_add( $table, $lit ) ){
				$did = true;
			}
		}
		
		if( intval( $LitID ) == $LitID ){
			if( self::_edit( $table, $LitID, $lit, 'LitID' ) ){
				$did = true;
			}
		}
		
		# Handle Linked Tables:
		if( $did ){
			
	#		echo '<pre>'.print_r( $_POST, true ).'</pre>';
			
			// LiteratureAudience
			self::_delete( 'LiteratureAudience', $LitID, 'LitID', 999 );
			if( $Audiences = self::_val( $_POST, 'Audience' ) ){
				foreach( $Audiences as $a ){
					self::_add( 'LiteratureAudience', array(
						'LitID'			=> $LitID,
						'AudienceID'	=> intval( $a ),
					) );
				}
			}
			
			// LiteratureContributor
			self::_delete( 'LiteratureContributor', $LitID, 'LitID', 999 );
			if( $Contributors = (array) self::_val( $_POST, 'Contributors' ) ){
	#			echo '<h3>Contributors</h3><pre>'.print_r( $Contributors, true ).'</pre>';
				foreach( $Contributors as $c ){
					$tmp = self::_get( 'Contributor', array( 'ID' => $c ), true );
					self::_add( 'LiteratureContributor', array(
						'LitID'				=> $LitID,
						'ContributorTypeID'	=> 1, # CHANGE THIS!!!!!
						'ContributorID'		=> $c,
						'Last'				=> $tmp['LastNameCorp'],
						'First'				=> $tmp['FirstName'],
						'Middle'			=> $tmp['Middle'],
						'Suffix'			=> $tmp['Suffix'],
					) );
				}
			}
			
			// LiteratureFormat
			self::_delete( 'LiteratureFormat', $LitID, 'LitID', 999 );
			if( $Formats = self::_val( $_POST, 'Format' ) ){
	#			echo '<h3>Formats</h3><pre>'.print_r( $Formats, true ).'</pre>';
				foreach( $Formats as $f ){
					self::_add( 'LiteratureFormat', array(
						'LitID'				=> $LitID,
						'FormatID'			=> $f,
					) );
				}
			}
			
			// LiteratureSubject
			self::_delete( 'LiteratureSubject', $LitID, 'LitID', 999 );
			if( $Subjects = self::_val( $_POST, 'Subject' ) ){
				foreach( $Subjects as $s ){
					self::_add( 'LiteratureSubject', array(
						'LitID'		=> $LitID,
						'SubjectID'	=> intval( $s ),
					) );
				}
			}
		}
		
		// Handle Delete Requests
		if( isset( $_REQUEST['delete'] ) ){
			if( $LitID = (int) $_REQUEST['delete'] ){
				if( self::_delete( $table, $LitID, 'LitID' ) ){
					self::_delete( 'LiteratureAudience',    $LitID, 'LitID', 999 );
					self::_delete( 'LiteratureContributor', $LitID, 'LitID', 999 );
					self::_delete( 'LiteratureFormat',      $LitID, 'LitID', 999 );
					self::_delete( 'LiteratureSubject',     $LitID, 'LitID', 999 );
					$did = true;
				}
			}
		}
		
		if( $did ){
			header( "Location: ?option=com_literaturedatabase&task=$table#row-item-$LitID" );
			exit;
		}
	}
	function _lit_attrib_list( $table, $str, $delim = ';' ){
		$db =& JFactory::getDBO();
		$arr = explode( $delim, $str );
		if( count( $arr ) ){
			$db->setQuery( "SELECT `Label` FROM `jos_litdb_$table` WHERE `ID` IN (".implode( ',', $arr ).")" );
			$r_str = '<ul class="lit_attrib_list">';
			foreach( $db->loadResultArray() as $label ){
				$r_str .= "<li>$label</li>";
			}
			$r_str .= '</ul>';
		}else{
			$r_str = self::_get_none();
		}
		return $r_str;
	}
	function _lit_single_attrib( $table, $id ){
		$db =& JFactory::getDBO();
		$id = (int) $id;
		if( $id ){
			$db->setQuery( "SELECT `Label` FROM `jos_litdb_$table` WHERE `ID` = '$id'" );
			$r_str = '<strong>'.$db->loadResult().'</strong>';
		}else{
			$r_str = self::_get_none();
		}
		return $r_str;
	}
	function _lit_contributors( $LitID = null ){
		$db =& JFactory::getDBO();
		$sql = "SELECT DISTINCT 
					c.ID AS `Value`,
					CONCAT(
						IFNULL(c.LastNameCorp, ''), 	', ', 
						IFNULL(c.FirstName, ''), 		' ',
						IFNULL(c.Middle, ''), 		' ', 
						IFNULL(c.Suffix, '')
					) AS `Option`
				FROM 
					`jos_litdb_Contributor` c
					INNER JOIN `jos_litdb_LiteratureContributor` lc 
						ON c.ID = lc.ContributorID ";
		if( $LitID ){
			$sql .= "
				WHERE 
					lc.LitID = '$LitID' ";
		}
		$sql .= "
				ORDER BY 
					c.LastNameCorp, 
					c.FirstName, 
					c.Middle ";
		$db->setQuery( $sql );
		$returnMe = array();
		foreach( $db->loadAssocList() as $contrib ){
			$returnMe[$contrib['Value']] = $contrib['Option'];
		}
		return $returnMe;
	}
	function _lit_formats( $LitID = null ){
		$db =& JFactory::getDBO();
		$sql = "SELECT DISTINCT 
					f.ID AS `Value`,
					f.Label as `Option`
				FROM 
					`jos_litdb_Format` f
					INNER JOIN `jos_litdb_LiteratureFormat` lf 
						ON f.ID = lf.FormatID ";
		if( $LitID ){
			$sql .= "
				WHERE 
					lf.LitID = '$LitID' ";
		}
		$sql .= "
				ORDER BY 
					f.Label ";
		$db->setQuery( $sql );
		$returnMe = array();
		foreach( $db->loadAssocList() as $format ){
			$returnMe[$format['Value']] = $format['Option'];
		}
		return $returnMe;
	}
	function _lit_subtable_opts( $table, $opts = array() ){
		$db =& JFactory::getDBO();
		$db->setQuery( "SELECT * FROM `jos_litdb_$table` ORDER BY `Label` ASC" );
		foreach( $db->loadAssocList( 'ID' ) as $id => $row ){
			$opts[$id] = $row['Label'];
		}
		return $opts;
	}
	function _y_n( $int ){
		if( (int) $int ){
			return self::_get_yes();
		}else{
			return self::_get_no();
		}
	}
	function _substr( $str, $len = 50 ){
		$str = strip_tags( $str );
		$r_str = '';
		if( strlen( $str ) ){
			if( strlen( $str ) > $len ){
				$r_str = '<span class="more">'.substr($str,0,$len).'<span class="ellipses">&hellip;</span><span class="more-text">'.substr($str,$len).'</span>';
			}else{
				$r_str = $str;
			}
		}else{
			$r_str = self::_get_none();
		}
		return $r_str;
	}
	function _link( $url, $title = null ){
		$r_str = '';
		if( strlen( $url ) ){
			if( empty( $title ) ){
				$r_str = '<a href="'.htmlentities($url).'" target="_blank">'.htmlentities($url).'</a>';
			}else{
				$r_str = '<a href="'.htmlentities($url).'" target="_blank">'.htmlentities($title).'</a>';
			}
		}else{
			$r_str = self::_get_none();
		}
		return $r_str;
	}
	function _get_none(){	return '<span class="lit-none">&laquo; none &raquo;</span>';	}
	function _get_yes()	{	return '<span class="lit-yes">Yes</span>';						}
	function _get_no()	{	return '<span class="lit-no">No</span>';						}
	function _array_to_list( array $array ){
		echo '<ul class="lit_attrib_list">';
		if( $array ){
			foreach( $array as $k => $v ){
				echo "<li class='list-id-$k'>$v</li>";
			}
		}
		echo '</ul>';
	}
	
// ================================================
// === Ordinary Pages =============================
// ================================================
	
	function ArticleType()		{self::_simple_page( __FUNCTION__ );}
	function Audience()			{self::_simple_page( __FUNCTION__ );}
	function BookType()			{self::_simple_page( __FUNCTION__ );}
	function ContributorType()	{self::_simple_page( __FUNCTION__ );}
	function Format()			{self::_simple_page( __FUNCTION__ );}
	function ReportType()		{self::_simple_page( __FUNCTION__ );}
	function Subject()			{self::_simple_page( __FUNCTION__ );}
	
	function _simple_page( $table ){
		self::_catch( $table );
		$db =& JFactory::getDBO();
		$db->setQuery( "SELECT * FROM `jos_litdb_$table` ".self::_order_by() );
		$items = $db->loadAssocList(); // items to show in the table
	#	$items = self::_get( $table );
		?>
		<h1><?php echo $table; ?></h1>
		<form method="post" action="?option=com_literaturedatabase&amp;task=<?php echo $table; ?>">
		<table class="list-table">
			<thead>
				<tr>
					<th scope="col"></th>
					<th scope="col">ID</th>
					<th scope="col">Label</th>
					<?php if( self::_mod_enable() ): ?><th scope="col">Actions</th><?php endif; ?>
				</tr>
			</thead>
			<tfoot>
				<tr>
					<th scope="col"></th>
					<th scope="col">ID</th>
					<th scope="col">Label</th>
					<?php if( self::_mod_enable() ): ?><th scope="col">Actions</th><?php endif; ?>
				</tr>
			</tfoot>
			<tbody>
				<?php if( $items ): foreach( $items as $k => $v ): ?>
				<tr id="row-item-<?php echo $v['ID']; ?>">
					<th scope="row"><input type="checkbox" name="ids[]" value="<?php echo $v['ID']; ?>" /></th>
					<td><?php echo $v['ID']; ?></td>
					<td><?php if( self::_mod_enable() && isset( $_GET['edit'] ) && ( $v['ID'] == $_GET['edit'] ) ): ?>
							<input type="hidden" name="edit-id" value="<?php echo $v['ID']; ?>" />
							<input type="text" name="edit-label" value="<?php echo $v['Label']; ?>" style="width:250px;" />
						<?php else: ?>
							<?php echo $v['Label']; ?>
						<?php endif; ?>
					</td>
					<?php if( self::_mod_enable() ): ?>
						<td>
							<?php if( isset( $_GET['edit'] ) && ( $v['ID'] == $_GET['edit'] ) ): ?>
								<input type="submit" name="edit-action" value="Edit &rarr;" />
							<?php else: ?>
								<a class="link-edit" href="?option=<?php echo $_GET['option']; ?>&amp;task=<?php echo $_GET['task']; ?>&amp;edit=<?php echo $v['ID']; ?>#row-item-<?php echo $v['ID']; ?>">Edit</a>
								<a class="link-delete" href="?option=<?php echo $_GET['option']; ?>&amp;task=<?php echo $_GET['task']; ?>&amp;delete=<?php echo $v['ID']; ?>">Delete</a>
							<?php endif; ?>
						</td>
					<?php endif; ?>
				</tr>
				<?php endforeach; endif; ?>
				<?php if( self::_mod_enable() && !isset( $_GET['edit'] ) ): ?>
				<tr>
					<th style="border-bottom:0;"></th>
					<td style="border-bottom:0;">NEW</td>
					<td style="border-bottom:0;"><input type="text" name="add-label" style="width:250px;" /></td>
					<td style="border-bottom:0;"><input type="submit" name="add-action" value="Add &rarr;" /></td>
				</tr>
				<?php endif; ?>
			</tbody>
		</table>
		</form>
		<?php
	}
	function _catch( $table ){
		$did = false;
		
		if( isset( $_REQUEST['add-action'] ) ){
			if( $id = self::_add( $table, array( 'Label' => $_REQUEST['add-label'] ) ) ){
				$did = true;
			}
		}
		
		if( isset( $_REQUEST['edit-action'] ) ){
			if( $id = (int) $_REQUEST['edit-id'] ){
				if( self::_edit( $table, $id, array( 'Label' => $_REQUEST['edit-label'] ) ) ){
					$did = true;
				}
			}
		}
		
		if( isset( $_REQUEST['delete'] ) ){
			if( $id = (int) $_REQUEST['delete'] ){
				if( self::_delete( $table, $id ) ){
					$did = true;
				}
			}
		}
		
		if( $did ){
			header( "Location: ?option=com_literaturedatabase&task=$table#row-item-$id" );
			exit;
		}
	}
	
	function _add( $table, $args = array() ){
		$sql = "INSERT INTO `jos_litdb_$table` ";
		if( count( $args ) ) { $sql .= " SET " . implode( " , ", self::_parse( $args ) ); }
		$db =& JFactory::getDBO();
		$db->setQuery( $sql );
		$db->query();
	#	echo "<h1>".__FUNCTION__."</h1>";
	#	echo "<pre>$sql</pre>";
	#	echo '<pre>';var_dump( $db );echo '</pre>';
		return $db->insertid();
	}
	function _edit( $table, $id, $args = array(), $index_col = 'ID' ){
		$sql = "UPDATE `jos_litdb_$table` ";
		if( count( $args ) ) { $sql .= " SET " . implode( " , ", self::_parse( $args ) ); }
		$sql .= " WHERE `$index_col` = '".intval( $id )."' LIMIT 1 ";
		$db =& JFactory::getDBO();
		$db->setQuery( $sql );
		$db->query();
	#	echo "<h1>".__FUNCTION__."</h1>";
	#	echo "<pre>$sql</pre>";
	#	echo '<pre>';var_dump( $db );echo '</pre>';
		return $id;
	#	return $db->getAffectedRows();
	}
	function _delete( $table, $id, $index_col = 'ID', $limit = 1 ){
		$sql = "DELETE FROM `jos_litdb_$table` WHERE `$index_col` = '".intval( $id )."' LIMIT $limit";
		$db =& JFactory::getDBO();
		$db->setQuery( $sql );
		$db->query();
		return $db->getAffectedRows();
	}
	function _get( $table, $args, $single = false ){
		$db =& JFactory::getDBO();
		$sql = "SELECT * 
				FROM `jos_litdb_$table` 
				WHERE ".implode( ' AND ', array_merge( array('1=1'), self::_parse( $args ) ) ).
				($single?' LIMIT 1':'');
		$db->setQuery( $sql );
		if( $single ){
			return $db->loadAssoc();
		}else{
			return $db->loadAssocList();
		}
	}
	function _parse( $args = Array() ){
		$params = Array();
		if( is_array( $args ) ){
			foreach( $args as $key => $value ){
				$params[] = " `$key` = '".addslashes( $value )."' ";
			}
		}
		return $params;
	}
	
	function _form_row( $name, $label, $value = NULL, $type = 'text', $options = array() ){
		if( 'text' == $type ):
			?>	<tr><th scope="row"><label for="frm_<?php echo $name; ?>"><?php echo $label; ?></label></th>
					<td><input class="widefat" type="text" id="frm_<?php echo $name; ?>" name="<?php echo $name; ?>" value="<?php echo $value; ?>" /></td></tr>
			<?php
		elseif( 'textarea' == $type ):
			?>	<tr><th scope="row"><label for="frm_<?php echo $name; ?>"><?php echo $label; ?></label></th>
					<td><textarea class="widefat" id="frm_<?php echo $name; ?>" name="<?php echo $name; ?>"><?php echo $value; ?></textarea></td></tr>
			<?php
		elseif( 'dropdown' == $type ):
			?>	<tr><th scope="row"><label for="frm_<?php echo $name; ?>"><?php echo $label; ?></label></th>
					<td><select data-placeholder=" " class="chosen-ui widefat" id="frm_<?php echo $name; ?>" name="<?php echo $name; ?>">
						<?php if( is_array( $options ) && $options ): foreach( $options as $option ): ?>
							<option<?php if( $option == $value ) echo ' selected="selected"'; ?>><?php echo $option; ?></option>
						<?php endforeach; endif; ?>
						</select></td></tr>
			<?php
		elseif( 'dropdown_assoc' == $type ):
			?>	<tr><th scope="row"><label for="frm_<?php echo $name; ?>"><?php echo $label; ?></label></th>
					<td><select data-placeholder=" " class="chosen-ui widefat" id="frm_<?php echo $name; ?>" name="<?php echo $name; ?>">
						<?php if( is_array( $options ) && $options ): foreach( $options as $option => $label ): ?>
							<option value="<?php echo $option; ?>" <?php if( $option == $value ) echo ' selected="selected"'; ?>><?php echo $label; ?></option>
						<?php endforeach; endif; ?>
						</select></td></tr>
			<?php
		elseif( 'multi' == $type ):
			?>	<tr><th scope="row"><label for="frm_<?php echo $name; ?>"><?php echo $label; ?></label></th>
					<td><select multiple="multiple" data-placeholder=" " class="chosen-ui widefat" id="frm_<?php echo $name; ?>" name="<?php echo $name; ?>[]">
						<?php if( is_array( $options ) && $options ): foreach( $options as $option ): ?>
							<option<?php if( in_array( $option, $value ) ) echo ' selected="selected"'; ?>><?php echo $option; ?></option>
						<?php endforeach; endif; ?>
						</select></td></tr>
			<?php
		elseif( 'multi_assoc' == $type ):
			?>	<tr><th scope="row"><label for="frm_<?php echo $name; ?>"><?php echo $label; ?></label></th>
					<td><select multiple="multiple" data-placeholder=" " class="chosen-ui widefat" id="frm_<?php echo $name; ?>" name="<?php echo $name; ?>[]">
						<?php if( is_array( $options ) && $options ): foreach( $options as $option => $label ): ?>
							<option value="<?php echo $option; ?>" <?php if( in_array( $option, $value ) ) echo ' selected="selected"'; ?>><?php echo $label; ?></option>
						<?php endforeach; endif; ?>
						</select></td></tr>
			<?php
		elseif( 'yn' == $type ):
			?>	<tr><th scope="row"><?php echo $label; ?></th>
					<td><label><input type="radio" name="<?php echo $name; ?>" value="1" <?php if('1'==$value) echo 'checked="checked" '; ?>/> Yes</label>
						<label><input type="radio" name="<?php echo $name; ?>" value="0" <?php if('0'==$value) echo 'checked="checked" '; ?>/> No</label></td></tr>
			<?php
		elseif( 'hidden' == $type ):
			?>	<input type="hidden" name="<?php echo $name; ?>" value="<?php echo $value; ?>" />
			<?php
		elseif( 'display' == $type ):
			?>	<tr><th scope="row"><label><?php echo $label; ?></label></th>
					<td><span id="frm_<?php echo $name; ?>_display"><?php echo $value; ?></span><input type="hidden" name="<?php echo $name; ?>" id="frm_<?php echo $name; ?>" value="<?php echo $value; ?>" /></td></tr>
			<?php
		elseif( 'submit' == $type ):
			?>	<tr><th></th>
					<td><input type="submit" class="button button-primary" value="<?php echo $value; ?> &rarr;" /></td></tr>
			<?php
		else:
			?>	<tr><th scope="row"><label for="frm_<?php echo $name; ?>"><?php echo $label; ?></label></th>
					<td><input type="<?php echo $type; ?>" id="frm_<?php echo $name; ?>" name="<?php echo $name; ?>" value="<?php echo $value; ?>" /></td></tr>
			<?php
		endif;
		
		return;
	}
	
	function _val( $array, $index, $otherwise = NULL ){
		if( is_array( $array ) && isset( $array[$index] ) ) {
			return $array[$index];
		} else {
			return $otherwise;
		}
	}

}
endif;