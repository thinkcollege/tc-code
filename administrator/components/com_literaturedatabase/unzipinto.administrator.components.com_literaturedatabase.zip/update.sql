ALTER TABLE  `jos_litdb_ArticleType` CHANGE  `ID`     `ID`    INT( 11 ) NOT NULL AUTO_INCREMENT;
ALTER TABLE  `jos_litdb_Contributor` CHANGE  `ID`     `ID`    INT( 11 ) NOT NULL AUTO_INCREMENT;
ALTER TABLE  `jos_litdb_Journal`     CHANGE  `JID`    `JID`   INT( 11 ) NOT NULL AUTO_INCREMENT;
ALTER TABLE  `jos_litdb_Literature`  CHANGE  `LitID`  `LitID` INT( 11 ) NOT NULL AUTO_INCREMENT;
